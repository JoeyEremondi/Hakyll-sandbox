securemem
=======

Documentation: [securemem on hackage](http://hackage.haskell.org/package/securemem)

older base
----------

An older base, the memory is not scrubed: upgrade your GHC to 7.6.0 or above.
